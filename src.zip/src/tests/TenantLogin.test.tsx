import React from 'react';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import TenantLogin from '../pages/TenantLogin';
import { AuthContext } from '../contexts/AuthContext';
import { fireEvent } from '@testing-library/react'; // Add this import statement

//importing other relevant pages
import PasswordResetOne from '../pages/PasswordResetOne.tsx';
import Tenant2FA from '../pages/Tenant2FA.tsx';
import PasswordResetTwo from '../pages/PasswordResetTwo.tsx';
import PasswordResetSuccessful from '../pages/PasswordResetSuccessful.tsx';
import PasswordResetUnsuccessful from '../pages/PasswordResetUnsuccessful.tsx';


// Mock the AuthContext to provide the required values
jest.mock('../contexts/AuthContext', () => ({
  AuthContext: {
    user: null,
    login: jest.fn(),
    logout: jest.fn(),
  },
}));

describe('TenantLogin', () => {
  it('renders the login form', () => {
    render(
      <MemoryRouter>
        <TenantLogin />
      </MemoryRouter>
    );

    // Assertions for the presence of form elements
    expect(screen.getByText('Tenant Portal')).toBeInTheDocument();
    expect(screen.getByText('Login')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Username')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Password')).toBeInTheDocument();
    expect(screen.getByText('Login')).toBeInTheDocument();
    expect(screen.getByText('Forgot your login details?')).toBeInTheDocument();
  });

  it('calls login function with the correct data when login button is clicked', () => {
    const mockLogin = jest.fn();
    const mockLogout = jest.fn();
    const mockUser = null;

    render(
      <MemoryRouter>
        <AuthContext.Provider value={{ user: mockUser, login: mockLogin, logout: mockLogout }}>
          <TenantLogin />
        </AuthContext.Provider>
      </MemoryRouter>
    );

    // Simulate user input by filling out the form
    fireEvent.change(screen.getByPlaceholderText('Username'), { target: { value: 'testuser' } });
    fireEvent.change(screen.getByPlaceholderText('Password'), { target: { value: 'testpassword' } });

    // Click the login button
    fireEvent.click(screen.getByText('Login'));

    // Assertions to check if the login function was called with the correct data
    expect(mockLogin).toHaveBeenCalledTimes(1);
    expect(mockLogin).toHaveBeenCalledWith({
      id: '1',
      email: 'JamieDole@yahoo.com.sg',
      userType: 1, // Tenant
      authToken: '5880',
    });
  });

  it('redirects to the correct dashboard based on userTypeFromBackend', () => {
    const mockNavigate = jest.fn();
    const mockUser = null;

    render(
      <MemoryRouter>
        <AuthContext.Provider value={{ user: mockUser, login: jest.fn(), logout: jest.fn() }}>
          <TenantLogin />
        </AuthContext.Provider>
      </MemoryRouter>
    );

    // Replace the navigate function with the mockNavigate
    // This will ensure the component uses the mocked function for navigation
    jest.spyOn(require('react-router-dom'), 'useNavigate').mockImplementation(() => mockNavigate);

    // Click the login button
    fireEvent.click(screen.getByText('Login'));

    // The navigate function should have been called with the correct route
    expect(mockNavigate).toHaveBeenCalledWith('/tenantDashboard');
  });

  it('redirects to reset1 when "Forgot your login details?" button is clicked', () => {
    const mockNavigate = jest.fn();
    const mockUser = null;

    render(
      <MemoryRouter>
        <AuthContext.Provider value={{ user: mockUser, login: jest.fn(), logout: jest.fn() }}>
          <TenantLogin />
        </AuthContext.Provider>
      </MemoryRouter>
    );

    // Replace the navigate function with the mockNavigate
    jest.spyOn(require('react-router-dom'), 'useNavigate').mockImplementation(() => mockNavigate);

    // Click the "Forgot your login details?" button
    fireEvent.click(screen.getByText('Forgot your login details?'));

    // The navigate function should have been called with the correct route
    expect(mockNavigate).toHaveBeenCalledWith('/reset1');
  });
});